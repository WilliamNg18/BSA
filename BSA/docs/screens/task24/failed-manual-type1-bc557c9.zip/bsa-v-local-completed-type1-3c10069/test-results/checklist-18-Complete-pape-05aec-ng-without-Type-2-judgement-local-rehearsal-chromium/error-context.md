# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: checklist.spec.ts >> 18 Complete paper retains human capture and existing pricing without Type 2 judgement
- Location: tests\live\checklist.spec.ts:439:1

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: getByRole('region', { name: 'Completed Type 1 captures', exact: true })
Expected: visible
Timeout: 5000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" getByRole('region', { name: 'Completed Type 1 captures', exact: true }) with timeout 5000ms
  - waiting for getByRole('region', { name: 'Completed Type 1 captures', exact: true })

```

```yaml
- banner:
  - link "Skip to main content":
    - /url: "#main-content"
  - link "Prescription Exception Case Builder":
    - /url: /#scene
  - navigation "Primary":
    - link "Overview":
      - /url: /
    - button "Operations"
    - button "How it works"
  - group "Perspective":
    - radio "Pharmacy"
    - text: Pharmacy
    - radio "NHSBSA"
    - text: NHSBSA
    - radio "Both" [checked]
    - text: Both
  - 'switch "Agent: Off"'
  - text: "On shows synthetic assistance. Off withholds recommendations; evidence and human decisions remain. Scene facts do not change. Agent : Off"
  - button "Reset demo"
- navigation "Guided tour":
  - button "Back"
  - button "Choose tour chapter": 6/8 · The queue
  - button "Next"
  - button "Dismiss tour"
- region "Demonstration scope and governing principle":
  - button "Synthetic demonstration data throughout. Hide details" [expanded]
  - paragraph: No payments calculated or approved. Not measured NHSBSA performance.
  - paragraph: The agent gathers evidence and recommends. Deterministic code validates and calculates. A human decides.
- main:
  - status: Assistance Off · Simulated presentation, not a model call
  - region "Tour chapter 6":
    - heading "6. The queue" [level=2]
    - paragraph: Explore assumed workloads and shared session submissions separately. Synthetic capacity estimates are not measured performance or automatic decisions.
  - text: Synthetic demonstration data
  - heading "NHSBSA exception queue" [level=1]
  - paragraph: "Type 2 worklist: review captured evidence, look up the Tariff and record your judgement."
  - region "Automatic pricing monthly aggregate":
    - text: Deterministic code
    - paragraph: 96,000,000 priced automatically this month, no person involved
    - paragraph: Shared monthly model, not session completions. Items are priced by NHSBSA's existing rules engine.
  - region "Actual session work counts":
    - heading "Actual synthetic session items" [level=2]
    - button "Awaiting Type 1 capture 10"
    - button "Awaiting Type 2 judgement 16"
    - button "Referred back 5"
    - button "Decided 1"
    - button "All staff items (32)" [pressed]
    - button "New submissions (1)"
  - status: "EX-24112: capture recorded. Follow the current routing; no Type 2 decision was made."
  - region "Type 2 worklist":
    - heading "Type 2 worklist" [level=2]
    - region "Type 2 items":
      - table:
        - rowgroup:
          - row "Reference Pharmacy Channel Reason it is here What the agent did Open":
            - columnheader "Reference"
            - columnheader "Pharmacy"
            - columnheader "Channel"
            - columnheader "Reason it is here"
            - columnheader "What the agent did"
            - columnheader "Open"
        - rowgroup:
          - row "EX-24112 New submission Hillcrest Pharmacy Paper Endorsement requires human interpretation. Not invoked; experience only Open EX-24112":
            - cell "EX-24112 New submission"
            - cell "Hillcrest Pharmacy"
            - cell "Paper"
            - cell "Endorsement requires human interpretation."
            - cell "Not invoked; experience only"
            - cell "Open EX-24112":
              - link "Open EX-24112":
                - /url: /case/EX-24112
                - text: Open
          - row "EX-24119 Oakfield Pharmacy EPS Conflicting evidence requires human judgement. Not invoked; experience only Open EX-24119":
            - cell "EX-24119"
            - cell "Oakfield Pharmacy"
            - cell "EPS"
            - cell "Conflicting evidence requires human judgement."
            - cell "Not invoked; experience only"
            - cell "Open EX-24119":
              - link "Open EX-24119":
                - /url: /case/EX-24119
                - text: Open
          - row "EX-24088 Hillcrest Pharmacy EPS Human judgement found insufficient information; RB code and reason required. Not invoked; experience only Open EX-24088":
            - cell "EX-24088"
            - cell "Hillcrest Pharmacy"
            - cell "EPS"
            - cell "Human judgement found insufficient information; RB code and reason required."
            - cell "Not invoked; experience only"
            - cell "Open EX-24088":
              - link "Open EX-24088":
                - /url: /case/EX-24088
                - text: Open
          - row "EX-24115 Meadow Lane Dispensary EPS Conflicting evidence requires human judgement. Not invoked; experience only Open EX-24115":
            - cell "EX-24115"
            - cell "Meadow Lane Dispensary"
            - cell "EPS"
            - cell "Conflicting evidence requires human judgement."
            - cell "Not invoked; experience only"
            - cell "Open EX-24115":
              - link "Open EX-24115":
                - /url: /case/EX-24115
                - text: Open
          - row "EX-24093 Hillcrest Pharmacy EPS Human judgement found insufficient information; RB code and reason required. Not invoked; experience only Open EX-24093":
            - cell "EX-24093"
            - cell "Hillcrest Pharmacy"
            - cell "EPS"
            - cell "Human judgement found insufficient information; RB code and reason required."
            - cell "Not invoked; experience only"
            - cell "Open EX-24093":
              - link "Open EX-24093":
                - /url: /case/EX-24093
                - text: Open
          - row "SYN-FQ123-1 Hillcrest Pharmacy EPS Endorsement requires human interpretation. Not invoked; experience only Open SYN-FQ123-1":
            - cell "SYN-FQ123-1"
            - cell "Hillcrest Pharmacy"
            - cell "EPS"
            - cell "Endorsement requires human interpretation."
            - cell "Not invoked; experience only"
            - cell "Open SYN-FQ123-1":
              - link "Open SYN-FQ123-1":
                - /url: /case/SYN-FQ123-1
                - text: Open
          - row "SYN-FQ123-3 Hillcrest Pharmacy EPS Conflicting evidence requires human judgement. Not invoked; experience only Open SYN-FQ123-3":
            - cell "SYN-FQ123-3"
            - cell "Hillcrest Pharmacy"
            - cell "EPS"
            - cell "Conflicting evidence requires human judgement."
            - cell "Not invoked; experience only"
            - cell "Open SYN-FQ123-3":
              - link "Open SYN-FQ123-3":
                - /url: /case/SYN-FQ123-3
                - text: Open
          - row "SYN-FQ123-5 Hillcrest Pharmacy EPS Endorsement requires human interpretation. Not invoked; experience only Open SYN-FQ123-5":
            - cell "SYN-FQ123-5"
            - cell "Hillcrest Pharmacy"
            - cell "EPS"
            - cell "Endorsement requires human interpretation."
            - cell "Not invoked; experience only"
            - cell "Open SYN-FQ123-5":
              - link "Open SYN-FQ123-5":
                - /url: /case/SYN-FQ123-5
                - text: Open
          - row "SYN-FH774-1 Riverside Chemist EPS Endorsement requires human interpretation. Not invoked; experience only Open SYN-FH774-1":
            - cell "SYN-FH774-1"
            - cell "Riverside Chemist"
            - cell "EPS"
            - cell "Endorsement requires human interpretation."
            - cell "Not invoked; experience only"
            - cell "Open SYN-FH774-1":
              - link "Open SYN-FH774-1":
                - /url: /case/SYN-FH774-1
                - text: Open
          - row "SYN-FH774-3 Riverside Chemist EPS Conflicting evidence requires human judgement. Not invoked; experience only Open SYN-FH774-3":
            - cell "SYN-FH774-3"
            - cell "Riverside Chemist"
            - cell "EPS"
            - cell "Conflicting evidence requires human judgement."
            - cell "Not invoked; experience only"
            - cell "Open SYN-FH774-3":
              - link "Open SYN-FH774-3":
                - /url: /case/SYN-FH774-3
                - text: Open
          - row "SYN-FH774-4 Riverside Chemist EPS Human judgement found insufficient information; RB code and reason required. Not invoked; experience only Open SYN-FH774-4":
            - cell "SYN-FH774-4"
            - cell "Riverside Chemist"
            - cell "EPS"
            - cell "Human judgement found insufficient information; RB code and reason required."
            - cell "Not invoked; experience only"
            - cell "Open SYN-FH774-4":
              - link "Open SYN-FH774-4":
                - /url: /case/SYN-FH774-4
                - text: Open
          - row "SYN-FH774-5 Riverside Chemist EPS Endorsement requires human interpretation. Not invoked; experience only Open SYN-FH774-5":
            - cell "SYN-FH774-5"
            - cell "Riverside Chemist"
            - cell "EPS"
            - cell "Endorsement requires human interpretation."
            - cell "Not invoked; experience only"
            - cell "Open SYN-FH774-5":
              - link "Open SYN-FH774-5":
                - /url: /case/SYN-FH774-5
                - text: Open
          - row "SYN-FM208-1 Oakfield Pharmacy EPS Endorsement requires human interpretation. Not invoked; experience only Open SYN-FM208-1":
            - cell "SYN-FM208-1"
            - cell "Oakfield Pharmacy"
            - cell "EPS"
            - cell "Endorsement requires human interpretation."
            - cell "Not invoked; experience only"
            - cell "Open SYN-FM208-1":
              - link "Open SYN-FM208-1":
                - /url: /case/SYN-FM208-1
                - text: Open
          - row "SYN-FM208-4 Oakfield Pharmacy EPS Human judgement found insufficient information; RB code and reason required. Not invoked; experience only Open SYN-FM208-4":
            - cell "SYN-FM208-4"
            - cell "Oakfield Pharmacy"
            - cell "EPS"
            - cell "Human judgement found insufficient information; RB code and reason required."
            - cell "Not invoked; experience only"
            - cell "Open SYN-FM208-4":
              - link "Open SYN-FM208-4":
                - /url: /case/SYN-FM208-4
                - text: Open
          - row "SYN-FM208-5 Oakfield Pharmacy EPS Endorsement requires human interpretation. Not invoked; experience only Open SYN-FM208-5":
            - cell "SYN-FM208-5"
            - cell "Oakfield Pharmacy"
            - cell "EPS"
            - cell "Endorsement requires human interpretation."
            - cell "Not invoked; experience only"
            - cell "Open SYN-FM208-5":
              - link "Open SYN-FM208-5":
                - /url: /case/SYN-FM208-5
                - text: Open
          - row "SYN-FT561-1 Station Road Pharmacy EPS Endorsement requires human interpretation. Not invoked; experience only Open SYN-FT561-1":
            - cell "SYN-FT561-1"
            - cell "Station Road Pharmacy"
            - cell "EPS"
            - cell "Endorsement requires human interpretation."
            - cell "Not invoked; experience only"
            - cell "Open SYN-FT561-1":
              - link "Open SYN-FT561-1":
                - /url: /case/SYN-FT561-1
                - text: Open
          - row "SYN-FT561-3 Station Road Pharmacy EPS Conflicting evidence requires human judgement. Not invoked; experience only Open SYN-FT561-3":
            - cell "SYN-FT561-3"
            - cell "Station Road Pharmacy"
            - cell "EPS"
            - cell "Conflicting evidence requires human judgement."
            - cell "Not invoked; experience only"
            - cell "Open SYN-FT561-3":
              - link "Open SYN-FT561-3":
                - /url: /case/SYN-FT561-3
                - text: Open
          - row "SYN-FT561-4 Station Road Pharmacy EPS Human judgement found insufficient information; RB code and reason required. Not invoked; experience only Open SYN-FT561-4":
            - cell "SYN-FT561-4"
            - cell "Station Road Pharmacy"
            - cell "EPS"
            - cell "Human judgement found insufficient information; RB code and reason required."
            - cell "Not invoked; experience only"
            - cell "Open SYN-FT561-4":
              - link "Open SYN-FT561-4":
                - /url: /case/SYN-FT561-4
                - text: Open
          - row "SYN-FT561-5 Station Road Pharmacy EPS Endorsement requires human interpretation. Not invoked; experience only Open SYN-FT561-5":
            - cell "SYN-FT561-5"
            - cell "Station Road Pharmacy"
            - cell "EPS"
            - cell "Endorsement requires human interpretation."
            - cell "Not invoked; experience only"
            - cell "Open SYN-FT561-5":
              - link "Open SYN-FT561-5":
                - /url: /case/SYN-FT561-5
                - text: Open
          - row "SYN-FK390-1 Meadow Lane Dispensary EPS Endorsement requires human interpretation. Not invoked; experience only Open SYN-FK390-1":
            - cell "SYN-FK390-1"
            - cell "Meadow Lane Dispensary"
            - cell "EPS"
            - cell "Endorsement requires human interpretation."
            - cell "Not invoked; experience only"
            - cell "Open SYN-FK390-1":
              - link "Open SYN-FK390-1":
                - /url: /case/SYN-FK390-1
                - text: Open
          - row "SYN-FK390-4 Meadow Lane Dispensary EPS Human judgement found insufficient information; RB code and reason required. Not invoked; experience only Open SYN-FK390-4":
            - cell "SYN-FK390-4"
            - cell "Meadow Lane Dispensary"
            - cell "EPS"
            - cell "Human judgement found insufficient information; RB code and reason required."
            - cell "Not invoked; experience only"
            - cell "Open SYN-FK390-4":
              - link "Open SYN-FK390-4":
                - /url: /case/SYN-FK390-4
                - text: Open
          - row "SYN-FK390-5 Meadow Lane Dispensary EPS Endorsement requires human interpretation. Not invoked; experience only Open SYN-FK390-5":
            - cell "SYN-FK390-5"
            - cell "Meadow Lane Dispensary"
            - cell "EPS"
            - cell "Endorsement requires human interpretation."
            - cell "Not invoked; experience only"
            - cell "Open SYN-FK390-5":
              - link "Open SYN-FK390-5":
                - /url: /case/SYN-FK390-5
                - text: Open
  - region "Type 1 capture lane":
    - heading "Type 1 capture lane" [level=2]
    - paragraph: Separate capture work. A person confirms the fields before code routes the item onward.
    - group:
      - text: EX-24123 · Meadow Lane Dispensary · Paper
      - region "Type 1 capture for EX-24123":
        - 'heading "Type 1: manual keying" [level=3]'
        - text: "Human decision Proposed: paper declaration support"
        - 'button "Manual: No guidance, experience only"'
        - heading "Original poor paper image" [level=4]
        - text: Existing NHSBSA capability
        - figure:
          - 'img "Synthetic scanned prescription form for case EX-24123. Item line reads: Co-cod?mol 30/5?0 t?bs 1??. Endorsement margin reads: N?S? ~~ 1?/0?."': "SYNTHETIC PRESCRIPTION FORM Patient: Patient D (synthetic) Age: -- NHS No: 000 000 0000 Form ref: EX-24123 Demo only: not a real form Prescribed items Pharmacy endorsement (for dispenser use) Co-cod?mol 30/5?0 t?bs 1?? Dispensed: 2026-08-27 Pharmacy: Meadow Lane Dispensary (FK390) N?S? ~~ 1?/0? Prescriber: Illegible Signature: ~~~~~~~~ Date: 2026-08-27"
        - paragraph: Synthetic poor scan. Declaration support does not improve image quality.
        - heading "Key what you can establish" [level=4]
        - paragraph: Leave unreadable fields blank. Do not guess; Type 2 can refer back with RB2B.
        - text: Product code
        - textbox "Product code"
        - paragraph: Human capture, not agent extraction
        - text: Quantity
        - textbox "Quantity"
        - paragraph: Human capture, not agent extraction
        - text: Endorsement
        - textbox "Endorsement"
        - paragraph: Human capture, not agent extraction
        - text: Prescriber
        - textbox "Prescriber"
        - paragraph: Human capture, not agent extraction
        - button "Confirm capture and continue to Type 2"
        - text: Manual keying stopwatch (assumption)
        - status "Assumed manual keying time": 30 seconds
        - text: Illustration, not elapsed work
        - button "Restart timing illustration"
        - paragraph: Difficult-example assumptions, not the public Type 1 average. Timing never confirms capture or changes the item.
        - group: Edit timing assumptions
        - text: Deterministic code
        - paragraph: Code routes after explicit capture. A compatible confirmed declaration can support a built Type 2 case with a dated clause.
        - paragraph: the agent verifies the submission and advises; a person decides
      - link "Open EX-24123":
        - /url: /case/EX-24123
    - group: EX-24104 · Riverside Chemist · Paper
    - group: EX-24109 · Oakfield Pharmacy · Paper
    - group: EX-24120 · Station Road Pharmacy · Paper
    - group: SYN-FQ123-2 · Hillcrest Pharmacy · Paper
    - group: SYN-FQ123-7 · Hillcrest Pharmacy · Paper
    - group: SYN-FH774-7 · Riverside Chemist · Paper
    - group: SYN-FM208-7 · Oakfield Pharmacy · Paper
    - group: SYN-FT561-7 · Station Road Pharmacy · Paper
    - group: SYN-FK390-7 · Meadow Lane Dispensary · Paper
  - 'heading "Shared monthly model: Today / With the agent" [level=2]'
  - paragraph: Public stream volumes with assumed handling effort; these projections are not actual session decisions.
  - term: Type 2 operator hours
  - definition: 7,222.2 / 21,849.7
  - term: Referred-back operator hours
  - definition: 5,666.7 / 4,533.3
  - term: Pharmacy completion hours
  - definition: 8,500 / 6,800
  - term: Items referred back
  - definition: 85,000 / 68,000
- contentinfo: "Session only · Synthetic cases · No payments calculated or approved Tour shortcuts: Alt + ← / → outside fields and menus"
- complementary "Decision notifications":
  - status
```

# Test source

```ts
  1  | import type { Page } from "@playwright/test";
  2  | import { expect, navigatePrimary } from "./fixtures";
  3  | import { choosePerspective } from "./perspective-helpers";
  4  | import { chooseProcessChapter } from "./process-model-helpers";
  5  | 
  6  | export const PAPER_B = "EX-24112";
  7  | export const completePaperFields = {
  8  |   productCode: "SYN-AMLO10-28", quantity: 28,
  9  |   endorsementText: "NCSO RK 21/08/26", prescriber: "Dr Demo (synthetic)",
  10 | };
  11 | type UiAction<T> = (label: string, side: "Pharmacy" | "NHSBSA", perform: () => Promise<void>) => Promise<T>;
  12 | 
  13 | export async function submitCompletePaper<T>(page: Page, action: UiAction<T>) {
  14 |   await action("Choose B for a new complete paper submission", "Pharmacy", async () => {
  15 |     await page.getByRole("radio", { name: "Information missing", exact: true }).check();
  16 |   });
  17 |   await action("Explicitly choose Paper rather than EPS", "Pharmacy", async () => {
  18 |     await page.getByRole("radio", { name: "Paper", exact: true }).check();
  19 |   });
  20 |   for (const [name, value] of [
  21 |     ["Declared product code", completePaperFields.productCode],
  22 |     ["Declared quantity", String(completePaperFields.quantity)],
  23 |     ["Declared prescriber (synthetic)", completePaperFields.prescriber],
  24 |     ["Endorsement entered by the pharmacy", completePaperFields.endorsementText],
  25 |   ]) {
  26 |     await action(`Declare paper ${name}`, "Pharmacy", async () => {
  27 |       await page.getByRole(name === "Declared quantity" ? "spinbutton" : "textbox", { name, exact: true }).fill(value);
  28 |     });
  29 |   }
  30 |   return action("Submit complete paper without confirming its capture", "Pharmacy", async () => {
  31 |     await page.getByRole("button", { name: "Continue with submission", exact: true }).click();
  32 |     await expect(page.getByRole("region", { name: "Submission receipt", exact: true })).toContainText(PAPER_B);
  33 |   });
  34 | }
  35 | 
  36 | export async function confirmCompletePaper<T>(page: Page, enabled: boolean, action: UiAction<T>) {
  37 |   await action("Navigate to actual Type 1 work", "NHSBSA", async () => { await navigatePrimary(page, "NHSBSA queue"); });
  38 |   await action("Open B's pending capture", "NHSBSA", async () => {
  39 |     await page.locator(`[data-type1-case="${PAPER_B}"] > summary`).click();
  40 |   });
  41 |   const capture = page.getByRole("region", { name: `Type 1 capture for ${PAPER_B}`, exact: true });
  42 |   const confirm = capture.getByRole("button", { name: "Confirm capture and continue", exact: true });
  43 |   if (enabled) {
  44 |     await expect(capture).toContainText("declared by the pharmacy, not read from the form");
  45 |     await action("Reject declaration prefill without reconciliation", "NHSBSA", async () => {
  46 |       await confirm.click();
  47 |       await expect(capture.getByRole("alert")).toContainText("Reconcile the declaration with the paper");
  48 |     });
  49 |     await action("Explicitly reconcile B's complete declaration", "NHSBSA", async () => {
  50 |       await capture.getByRole("checkbox", { name: "I have reconciled the declaration with the paper", exact: true }).check();
  51 |     });
  52 |   } else {
  53 |     for (const [name, value] of [
  54 |       ["Product code", completePaperFields.productCode], ["Quantity", String(completePaperFields.quantity)],
  55 |       ["Endorsement", completePaperFields.endorsementText], ["Prescriber", completePaperFields.prescriber],
  56 |     ]) {
  57 |       await expect(capture.getByRole("textbox", { name, exact: true })).toHaveValue("");
  58 |       await action(`Manually capture B ${name}`, "NHSBSA", async () => {
  59 |         await capture.getByRole("textbox", { name, exact: true }).fill(value);
  60 |       });
  61 |     }
  62 |   }
  63 |   return action("Confirm complete Type 1 evidence without Type 2 judgement", "NHSBSA", async () => {
  64 |     await confirm.click();
> 65 |     await expect(page.getByRole("region", { name: "Completed Type 1 captures", exact: true })).toBeVisible();
     |                                                                                                ^ Error: expect(locator).toBeVisible() failed
  66 |     await expect(capture.getByRole("heading", { name: "Human capture confirmed", exact: true })).toBeVisible();
  67 |   });
  68 | }
  69 | 
  70 | export async function openFourCases(page: Page) {
  71 |   const wasBoth = await page.getByRole("radio", { name: "Both", exact: true }).isChecked();
  72 |   await choosePerspective(page, "Both");
  73 |   await navigatePrimary(page, "Overview");
  74 |   await chooseProcessChapter(page, 4);
  75 |   if (!wasBoth) await choosePerspective(page, "NHSBSA");
  76 | }
  77 | 
```